# Gestión del Gym — Studio Functional Fitness

Aplicación standalone (Next.js + Supabase) para gestionar el gym fuera de Muse,
con tu propio dominio en Vercel. Replica la app de Muse: Hoy, Clases, Pagos (MXN),
Rutinas, Ejercicios, Clientes y Accesos por rol, con el logo de Studio Functional Fitness.

## Dos modos

| Modo | Cuándo | Datos |
| --- | --- | --- |
| **Demo / local** | Sin variables de entorno | Se guardan en el navegador (localStorage). Sirve para probar el despliegue en Vercel inmediatamente. Cada navegador ve sus propios datos. |
| **Supabase** | Con `NEXT_PUBLIC_SUPABASE_URL` y `NEXT_PUBLIC_SUPABASE_ANON_KEY` | Base de datos compartida en Supabase. Todos los usuarios ven los mismos datos. Es el modo que quieres para el gym. |

La app detecta el modo sola: si hay variables de Supabase, las usa; si no, modo demo.

## Estructura

```
app/            Páginas: Hoy (/), Clases, Pagos, Rutinas, Ejercicios, Clientes, Accesos, Portal
components/     Logo, Header (navegación por rol), Login (usuario + PIN)
lib/            types.ts, seed.ts (22 ejercicios + datos iniciales), store.tsx (estado + Supabase/local),
                supabaseClient.ts, utils.ts (MXN, WhatsApp wa.me, avisos 5 días)
public/logo.jpg Logo de Studio Functional Fitness
supabase/       schema.sql (tablas) y seed.sql (datos iniciales)
```

## Roles

- **Administrador (solo Carlos):** acceso completo, incluidos Pagos y Accesos. Crea su cuenta primero.
- **Entrenador:** panel diario, Clases, Rutinas, Ejercicios y Clientes. No ve Pagos ni importes y no puede eliminar clientes.
- **Cliente:** solo su portal — su rutina día a día, próximas clases (reservar/cancelar), sus pagos y su progreso.

Entrar: usuario + PIN. La primera vez, la app pide crear la cuenta de administrador.
Desde Accesos se crean las cuentas de entrenadores y clientes (vinculadas a su ficha).

## Pagos y WhatsApp

- Importes en pesos mexicanos (`es-MX` / MXN), método SPEI.
- El botón de WhatsApp solo aparece en pagos sin pagar. Abre `wa.me` con el mensaje ya
  redactado (concepto, importe MXN y fecha). Teléfonos mexicanos de 10 dígitos → prefijo 52.
- **Avisos:** los pagos sin pagar que vencen en exactamente 5 días se destacan como
  «avisar hoy»; también se muestran los que vencen en los próximos 5 días, los que vencen
  hoy y los vencidos. El envío se confirma en WhatsApp, no es automático.

## Despliegue en Vercel (paso a paso)

### 1. Sube el proyecto a GitHub
Crea un repositorio (p. ej. `gestion-del-gym`) y sube el contenido de esta carpeta.
No subas `.env.local` ni secretos.

### 2. Crea la base de datos en Supabase
1. En [supabase.com](https://supabase.com), crea un proyecto.
2. En **SQL Editor → New query**, pega y ejecuta `supabase/schema.sql`.
3. En otra query, pega y ejecuta `supabase/seed.sql`.
4. En **Settings → API**, copia la **Project URL** y la **anon public key**.

> Si quieres probar sin base de datos, sáltate este paso: la app arranca en modo demo.

### 3. Despliega en Vercel
1. En [vercel.com](https://vercel.com), **Add New → Project → Import** el repositorio de GitHub.
2. Framework: Next.js (se detecta solo). Build command: `npm run build`.
3. En **Environment Variables**, añade:
   - `NEXT_PUBLIC_SUPABASE_URL` = la Project URL de Supabase
   - `NEXT_PUBLIC_SUPABASE_ANON_KEY` = la anon key de Supabase
4. **Deploy**. Obtendrás una URL tipo `gestion-del-gym.vercel.app`.

### 4. Añade tu dominio propio
En Vercel: **Project → Settings → Domains → Add** tu dominio (p. ej. `gym.tudominio.com`)
y sigue las instrucciones de DNS en tu registrador. Vercel emite el certificado HTTPS.

### 5. Crea tu cuenta de administrador
Abre la app desplegada, crea la cuenta de administrador (usuario + PIN) y, en Accesos,
crea las cuentas de entrenadores y clientes. **Cambia los PIN de ejemplo y no los
compartas por chat.**

### 6. Comprueba que todo funciona
Entra como administrador, revisa Hoy / Pagos / Clases, entra como cliente en su portal
y confirma que cada rol ve solo lo suyo.

## Desarrollo local

```bash
npm install
cp .env.example .env.local   # opcional; sin él, modo demo
npm run dev                  # http://localhost:3000
npm run build                # debe pasar sin errores
```

## Seguridad — léelo antes de usarlo con clientes reales

- Los PIN se guardan como `pin_hash` en Supabase; en esta primera versión el hash es
  el PIN tal cual en el flujo de la app (igual que en la app de Muse). Para producción,
  sustitúyelo por un hash real (bcrypt/argon2) en el servidor o por Supabase Auth.
- Las políticas RLS de `schema.sql` son permisivas a propósito para que la app funcione
  sin Auth. Para producción, restrínjelas con Supabase Auth (`auth.uid()`) y usa la
  `service_role` key solo en el servidor, nunca en el navegador.
- El aviso diario de las 10:00 que tenías en Muse no viaja con esta app: en Vercel
  habría que hacerlo con un Cron Job de Vercel + la acción de avisos, o mantener el
  aviso de Muse aparte.

## Datos iniciales

- Clientes: Carlos (4426771084, Hyrox) y Camilla Barnes (+44 7780 663864, Spinning).
- Pagos: 2 × $550.00 MXN «Cuota mensual», vencimiento 2026-11-25, sin pagar.
- Clase: Hyrox, 27 nov 2026, 18:00, 60 min, Jesus, 12 plazas.
- Ejercicios: 22 (fuerza, HYROX, cardiovascular, core y movilidad).
- Rutinas, asignaciones, reservas y progreso: vacíos, como en la app original.
