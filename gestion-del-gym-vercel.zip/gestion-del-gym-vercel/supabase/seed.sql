-- Gestión del Gym — datos iniciales (los de la app de Muse, 2026-11-25).
-- Ejecutar DESPUÉS de schema.sql, en el SQL Editor de Supabase.
-- Los IDs se fijan explícitamente para que coincidan con la app original.
-- PINs: NO hay usuarios en esta semilla. Crea el administrador desde la
-- propia app (pantalla "Crea tu cuenta de administrador") y cambia los
-- PIN de ejemplo que pongas. No guardes PIN reales en este archivo.

insert into members (id, name, phone, email, plan, goal, start_date, status, notes) values
  (1, 'Carlos', '4426771084', '', 'Mensual', 'Hyrox', '2026-11-25', 'activo', ''),
  (2, 'Camilla Barnes', '+44 7780 663864', '', 'Mensual', 'Spinning', '2026-11-25', 'activo', '')
on conflict (id) do nothing;

insert into classes (id, title, type, date, start_time, duration_min, coach, capacity, notes) values
  (1, 'Hyrox', 'Sesión grupal', '2026-11-27', '18:00', 60, 'Jesus', 12, '')
on conflict (id) do nothing;

insert into payments (id, member_id, concept, amount_cents, due_date, paid_date, method) values
  (1, 1, 'Cuota mensual', 55000, '2026-11-25', null, ''),
  (2, 2, 'Cuota mensual', 55000, '2026-11-25', null, '')
on conflict (id) do nothing;

insert into exercises (id, name, category, muscle_group, equipment, description) values
  (1, 'Sentadilla con barra', 'Fuerza', 'Piernas', 'Barra y rack', 'Sentadilla completa con barra en la espalda, bajando hasta romper el paralelo.'),
  (2, 'Peso muerto', 'Fuerza', 'Cadena posterior', 'Barra', 'Bisagra de cadera con barra desde el suelo, espalda neutra.'),
  (3, 'Press de banca', 'Fuerza', 'Pecho', 'Barra y banco', 'Press horizontal con barra, controlando la bajada.'),
  (4, 'Press militar', 'Fuerza', 'Hombros', 'Barra o mancuernas', 'Empuje vertical por encima de la cabeza.'),
  (5, 'Dominadas', 'Fuerza', 'Espalda', 'Barra de dominadas', 'Tracción vertical con peso corporal, agarre prono o supino.'),
  (6, 'Remo con barra', 'Fuerza', 'Espalda', 'Barra', 'Tracción horizontal inclinado, barra hacia el abdomen.'),
  (7, 'Zancadas', 'Fuerza', 'Piernas', 'Mancuernas', 'Zancadas alternas o caminando, con o sin carga.'),
  (8, 'Hip thrust', 'Fuerza', 'Glúteos', 'Barra y banco', 'Empuje de cadera con la espalda apoyada en banco.'),
  (9, 'Empuje de trineo (sled push)', 'HYROX', 'Piernas', 'Trineo', 'Empuje de trineo cargado en distancia, estación HYROX.'),
  (10, 'Tirón de trineo (sled pull)', 'HYROX', 'Espalda y piernas', 'Trineo y cuerda', 'Tirón de trineo con cuerda, estación HYROX.'),
  (11, 'Wall balls', 'HYROX', 'Cuerpo completo', 'Balón medicinal', 'Sentadilla y lanzamiento de balón a la diana, estación HYROX.'),
  (12, 'SkiErg', 'HYROX', 'Tren superior', 'SkiErg', 'Distancia en SkiErg, estación HYROX y trabajo cardiovascular.'),
  (13, 'Remo (RowErg)', 'HYROX', 'Cuerpo completo', 'Remo ergómetro', 'Distancia en remo ergómetro, estación HYROX.'),
  (14, 'Farmers carry', 'HYROX', 'Agarre y core', 'Kettlebells o mancuernas', 'Transporte de cargas pesadas en distancia, estación HYROX.'),
  (15, 'Burpee broad jump', 'HYROX', 'Cuerpo completo', 'Peso corporal', 'Burpee con salto hacia adelante, estación HYROX.'),
  (16, 'Sandbag lunges', 'HYROX', 'Piernas', 'Saco de arena', 'Zancadas caminando con saco sobre los hombros, estación HYROX.'),
  (17, 'Carrera continua', 'Cardiovascular', 'Piernas', 'Cinta o exterior', 'Carrera a ritmo constante para base aeróbica.'),
  (18, 'Intervalos de carrera', 'Cardiovascular', 'Piernas', 'Cinta o exterior', 'Series de carrera rápida con recuperación activa.'),
  (19, 'Assault bike', 'Cardiovascular', 'Cuerpo completo', 'Bici de aire', 'Trabajo por calorías o intervalos en bici de aire.'),
  (20, 'Plancha', 'Core', 'Core', 'Peso corporal', 'Isométrico de core en apoyo de antebrazos.'),
  (21, 'Dead hang', 'Core', 'Agarre', 'Barra de dominadas', 'Colgarse de la barra para fuerza de agarre y hombros.'),
  (22, 'Movilidad de cadera', 'Movilidad', 'Cadera', 'Peso corporal', 'Rutina de movilidad y apertura de cadera.')
on conflict (id) do nothing;

-- Rutinas, asignaciones, reservas y progreso: 0 en la app original, se empieza vacío.
-- Secuencias al día tras insertar IDs fijos:
select setval(pg_get_serial_sequence('members', 'id'), (select max(id) from members));
select setval(pg_get_serial_sequence('classes', 'id'), (select max(id) from classes));
select setval(pg_get_serial_sequence('payments', 'id'), (select max(id) from payments));
select setval(pg_get_serial_sequence('exercises', 'id'), (select max(id) from exercises));
